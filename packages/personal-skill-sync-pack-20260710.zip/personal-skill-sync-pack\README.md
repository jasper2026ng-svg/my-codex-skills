# Personal Skill Sync Pack

This package copies selected personal Codex skills to another Windows computer.

## Included Skills

- `structured-problem-framing`
- `first-principles-reframing`

## Install On Another Windows Computer

1. Copy this folder, or the `.zip` generated beside it, to the other computer.
2. If using the `.zip`, extract it first.
3. Open PowerShell in the extracted folder.
4. Run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-windows.ps1
```

If a skill already exists and you want to replace it with this package version:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-windows.ps1 -Force
```

With `-Force`, the existing skill folder is backed up under the target skills directory before replacement.

## Verify The Package

Before installing, you can verify the package structure:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\verify-package.ps1
```

## Target Directory

By default, skills are installed to:

```text
%USERPROFILE%\.codex\skills
```

For most Windows users this is:

```text
C:\Users\<your-user>\.codex\skills
```

Restart Codex if the skills do not appear immediately.

$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceSkillsDir = Join-Path $PackageRoot "skills"

if (-not (Test-Path -LiteralPath $SourceSkillsDir)) {
    throw "Missing skills directory: $SourceSkillsDir"
}

$skills = Get-ChildItem -LiteralPath $SourceSkillsDir -Directory
if ($skills.Count -eq 0) {
    throw "No skill folders found."
}

foreach ($skill in $skills) {
    $skillMd = Join-Path $skill.FullName "SKILL.md"
    $agentYaml = Join-Path $skill.FullName "agents\openai.yaml"
    if (-not (Test-Path -LiteralPath $skillMd)) {
        throw "Missing SKILL.md: $($skill.Name)"
    }

    $content = Get-Content -Raw -LiteralPath $skillMd
    if ($content -notmatch "(?s)^---\s*.*?name:\s*$([regex]::Escape($skill.Name))\s*.*?description:\s*.+?\s*---") {
        throw "Frontmatter check failed: $($skill.Name)"
    }

    if (-not (Test-Path -LiteralPath $agentYaml)) {
        Write-Host "[WARN] Missing agents/openai.yaml: $($skill.Name)"
    } else {
        Write-Host "[OK] $($skill.Name)"
    }
}

Write-Host ""
Write-Host "Package verification passed. Skill count: $($skills.Count)"

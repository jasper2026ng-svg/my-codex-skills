param(
    [string]$TargetSkillsDir = (Join-Path $env:USERPROFILE ".codex\skills"),
    [switch]$Force,
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceSkillsDir = Join-Path $PackageRoot "skills"

if (-not (Test-Path -LiteralPath $SourceSkillsDir)) {
    throw "Missing skills directory: $SourceSkillsDir"
}

$skillDirs = Get-ChildItem -LiteralPath $SourceSkillsDir -Directory
if ($skillDirs.Count -eq 0) {
    throw "No skills found under: $SourceSkillsDir"
}

foreach ($skill in $skillDirs) {
    $skillMd = Join-Path $skill.FullName "SKILL.md"
    if (-not (Test-Path -LiteralPath $skillMd)) {
        throw "Invalid skill package; missing SKILL.md in $($skill.FullName)"
    }
}

Write-Host "Personal Skill Sync Pack"
Write-Host "Source: $SourceSkillsDir"
Write-Host "Target: $TargetSkillsDir"
Write-Host ""

if ($DryRun) {
    Write-Host "Dry run only. No files will be copied."
} else {
    New-Item -ItemType Directory -Force -Path $TargetSkillsDir | Out-Null
}

$backupRoot = $null
if ($Force -and -not $DryRun) {
    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $backupRoot = Join-Path $TargetSkillsDir "_backup_personal_skill_sync_$timestamp"
}

$installed = @()
$skipped = @()

foreach ($skill in $skillDirs) {
    $target = Join-Path $TargetSkillsDir $skill.Name

    if (Test-Path -LiteralPath $target) {
        if (-not $Force) {
            Write-Host "[SKIP] $($skill.Name) already exists. Use -Force to back up and replace."
            $skipped += $skill.Name
            continue
        }

        if ($DryRun) {
            Write-Host "[DRY] Would back up and replace $($skill.Name)"
            $installed += $skill.Name
            continue
        }

        if (-not $backupRoot) {
            throw "Internal error: backup path was not initialized."
        }
        New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
        Copy-Item -LiteralPath $target -Destination $backupRoot -Recurse
        Remove-Item -LiteralPath $target -Recurse -Force
        Write-Host "[BACKUP] Existing $($skill.Name) copied to $backupRoot"
    }

    if ($DryRun) {
        Write-Host "[DRY] Would install $($skill.Name)"
    } else {
        Copy-Item -LiteralPath $skill.FullName -Destination $target -Recurse
        $installedSkillMd = Join-Path $target "SKILL.md"
        if (-not (Test-Path -LiteralPath $installedSkillMd)) {
            throw "Install verification failed for $($skill.Name)"
        }
        Write-Host "[OK] Installed $($skill.Name)"
    }

    $installed += $skill.Name
}

Write-Host ""
Write-Host "Result:"
Write-Host "Installed: $($installed.Count)"
foreach ($name in $installed) { Write-Host "  - $name" }
Write-Host "Skipped: $($skipped.Count)"
foreach ($name in $skipped) { Write-Host "  - $name" }

if (-not $DryRun) {
    Write-Host ""
    Write-Host "Restart Codex on this computer if the skills do not appear immediately."
}
